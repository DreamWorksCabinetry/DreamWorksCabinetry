export function Input(props){ return <input {...props} style={{padding:'.6rem .8rem', border:'1px solid #e5e7eb', borderRadius:'.75rem', width:'100%'}}/>; }
