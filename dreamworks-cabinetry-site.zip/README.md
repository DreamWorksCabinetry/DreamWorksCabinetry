# DreamWorks Cabinetry – Website (Next.js)

## Quick Start
1. Install: `npm install`
2. Run locally: `npm run dev`
3. Build for production: `npm run build && npm start`

## Updating the Gallery (Easy Drag-and-Drop)
- Put new photos into **/public/gallery**.
- Run `npm run gallery` to auto-update **/public/gallery/index.json** (or edit that file manually).
- Deploy.

## Contact details
- Phone: (256) 674-3373 – Juan Gonzalez
- Phone: (256) 996-3114 – Philip McElhaney
- Email: mcelhaneyphilip@gmail.com
- Address: 47141 US HIGHWAY 11, Valley Head, AL 35989

## Notes
- If `/public/logo.png` isn't your final logo yet, replace it with your business card logo.
- Homepage highlights are in `/public/portfolio` – replace empty placeholder files with real photos to update.
